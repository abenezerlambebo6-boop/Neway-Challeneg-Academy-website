# Ethiopian textbook catalog research

Checked 13 October 2026. This folder is research input for the website, not a claim that the school has approved the editions.

## Main sources

1. Amhara National Regional State Education Bureau — New Textbooks
   https://anrseb.gov.et/downloads/new-textbooks/
   Web reference: turn27view0. Official regional government source. The catalog links 78 student PDFs: 56 across Grades 1–8, 11 each in Grades 9 and 10. Its Grade 11–12 subject headings have no download links. The page names the collection “New Textbooks.” Primary edition years and most book languages have not been verified; preserve null metadata rather than inventing it.

2. St John Baptist De La Salle school — Ministry textbooks library
   https://lts.stjohn.edu.et/find-borrow-request/moe-textbooks
   Web references: turn6view2, turn17search5. Another school's educational library, not an official Ministry host. Its HTML embeds 46 Google Drive PDF viewers whose filenames label them 2023 student textbooks. Each viewer has been checked for a returned page title matching its book. It fills secondary subject gaps, especially Grades 11–12; alternate links are retained for Grades 9–10 books already in the Bureau source.

3. Ministry of Education Learn English
   https://learn-english.moe.gov.et/
   https://learn-english.moe.gov.et/resource-view/1416/25
   Web references: turn5search2, turn14search1 / turn16search0. The latter is a Grade 8 English textbook page with an actual PDF link. Ministry-hosted Grade 1, 2, 9, 10 English PDF links were also discovered in search results: turn3search7, turn14search11, turn5search43, turn5search42. These are additional sources, not needed to inflate the core catalog count.

4. Ministry of Education Study LMS
   https://study.moe.gov.et/
   Web reference: turn10view1. Intact official learning site describing K–12 study. Current visible courses include Grade 8 General Science and Grade 8 English; it is not a complete textbook library.

5. Sidama Regional Education Bureau
   https://www.sreb.gov.et/EDUCATION/node/62
   https://www.sreb.gov.et/EDUCATION/node/77
   Web references: turn19view1, turn19view2. Genuine regional source with additional PDF files, including urban/rural editions. Not merged into the core catalog because its edition mix would need more validation for an Addis Ababa school.

## Link verification

The core catalog uses the exact links extracted from actual source HTML. For Bureau links, verification requests inspect the PDF signature (%PDF-) without bulk downloading the books. Verified file URLs are in pdfUrl. A source listing alone is not treated as a verified PDF.

The school-mirror viewer URLs are derived from the exact embedded Drive file IDs. All 46 returned expected textbook titles. These are viewer links, not direct PDF-download endpoints, so they are stored in viewerUrl; pdfUrl remains null.

Use a book's pdfUrl if present, otherwise viewerUrl, otherwise sourceUrl. Label the button Open PDF / Read textbook / View source respectively. Open external links in a new tab with noopener/noreferrer. Keep the source name visible or within book details.

## Important limits

- The catalog has 102 unique grade/subject pairs. It does not establish a complete subject list for this particular school.
- Amhara regional primary editions may differ from Addis Ababa editions and classroom language. A primary teacher should match each book to the school’s approved copy before describing it as school-approved.
- Grade 11 and 12 Amharic were found in a third-party listing (Kehulum), but pages returned 403 on fetch, so no verified links are included. All regional/mother-tongue language variants are not covered.
- A 2023 filename verifies the source's edition label, not a full inspection of every page. The 2026 school year may use a selected edition or local supplement.
- No book is marked schoolAligned=true. That can only change after an owner or teacher confirms the school's editions.
- The Ministry root https://moe.gov.et/ returned unrelated gambling content during this check (turn10view0). Its /Publication page returned 404. Do not place the Ministry root or old lib.moe.gov.et downloads in this student site merely because the domain is government. Intact Ministry subdomains can be linked individually.

## Study-assistant implementation implications

A Google search shortcut is not a working AI tutor. If no server-side model/search backend is connected, describe the current function honestly as textbook finder or guided search. A real tutor should use grade, subject, language, exact approved edition, and chapter/page to retrieve the book first; cite the supporting page; distinguish curriculum answers from broader explanations; and say when the approved book lacks evidence. Do not claim guaranteed exact curriculum alignment from a grade selector alone. Keep API credentials on the server and require owner authentication for content changes.

The user explicitly wants the assigned curriculum retained even if an alternative source differs. Preserve the textbook wording/definitions when giving a textbook-based answer and identify the source; do not silently rewrite the curriculum. Do not fabricate a textbook citation or pretend web results were retrieved if the app only opened a Google tab.
