import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '@/app/chatgpt-auth';
import catalog from '@/lib/data/catalog.json';
import {selectBook,validHistory,tutorInstruction} from '@/lib/tutor-logic.mjs';

export const dynamic='force-dynamic';
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'private, no-store'}});
const config=()=>env as {GEMINI_API_KEY?:string;GEMINI_MODEL?:string;NEWAY_AI_ENABLED?:string};
const enabled=()=>!!config().GEMINI_API_KEY&&config().NEWAY_AI_ENABLED==='true';
const safeURL=(url:unknown):url is string=>{try{return typeof url==='string'&&new URL(url).protocol==='https:';}catch{return false;}};
const recent=new Map<string,{started:number;count:number}>();
export async function GET(){return json({available:enabled()});}
export async function POST(request:Request){
  if(request.headers.get('origin')!==new URL(request.url).origin)return json({error:'Please ask from this website.'},403);
  if(!await getChatGPTUser())return json({error:'Please sign in to this private school website to continue.'},401);
  if(!enabled())return json({error:'The AI service is not connected yet. The textbook library is available.'},503);
  if(!(request.headers.get('content-type')||'').includes('application/json'))return json({error:'Invalid request format.'},400);
  if(Number(request.headers.get('content-length')||0)>20000)return json({error:'Please shorten the conversation.'},413);
  let input:{grade?:unknown;subject?:unknown;question?:unknown;history?:unknown};
  try{const raw=await request.text();if(raw.length>18000)return json({error:'Please start a new conversation.'},413);input=JSON.parse(raw);}catch{return json({error:'The question could not be read.'},400);}
  if(typeof input.question!=='string'||!input.question.trim()||input.question.length>2000||!Number.isInteger(input.grade)||Number(input.grade)<1||Number(input.grade)>12)return json({error:'Choose your grade and ask a question under 2,000 characters.'},400);
  const grade=Number(input.grade),question=input.question.trim();
  const subject=typeof input.subject==='string'?input.subject:'';
  if(subject&&!catalog.some(b=>b.grade===grade&&b.subject===subject))return json({error:'Choose a subject available for your grade.'},400);
  const user=(await getChatGPTUser())!;const now=Date.now();const limit=recent.get(user.userId);
  if(limit&&now-limit.started<60000&&limit.count>=8)return json({error:'Please wait a minute before asking another question.'},429);
  if(recent.size>1000)for(const[id,value]of recent)if(now-value.started>60000)recent.delete(id);
  recent.set(user.userId,{started:limit&&now-limit.started<60000?limit.started:now,count:limit&&now-limit.started<60000?limit.count+1:1});
  const history=validHistory(input.history);
  const previous=Array.isArray(input.history)?input.history.filter(m=>m&&m.role==='user'&&typeof m.text==='string').map(m=>m.text).join(' ').slice(-3000):'';
  const book=selectBook(catalog,grade,subject,question+' '+previous);
  const bookUrl=book?.pdfUrl||book?.viewerUrl;
  try{
    const {GEMINI_API_KEY,GEMINI_MODEL}=config();
    const response=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(GEMINI_MODEL||'gemini-2.5-flash')+':generateContent',{
      method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':GEMINI_API_KEY!},signal:AbortSignal.timeout(45000),
      body:JSON.stringify({system_instruction:{parts:[{text:tutorInstruction(grade,book)}]},contents:[...history,{role:'user',parts:[{text:question}]}],tools:[{url_context:{}},{google_search:{}}],generationConfig:{temperature:.2,maxOutputTokens:2200}})
    });
    if(!response.ok)return json({error:response.status===429?'The AI service is busy. Please try again shortly.':'The AI service could not answer. Please try again or check your textbook.'},502);
    const data=await response.json() as {candidates?:Array<{content?:{parts?:Array<{text?:string}>};urlContextMetadata?:{urlMetadata?:Array<{retrievedUrl?:string;urlRetrievalStatus?:string}>};groundingMetadata?:{groundingChunks?:Array<{web?:{title?:string;uri?:string}}> ;groundingSupports?:Array<{segment?:{endIndex?:number};groundingChunkIndices?:number[]}>;searchEntryPoint?:{renderedContent?:string}}}>};
    const candidate=data.candidates?.[0];let answer=candidate?.content?.parts?.map(p=>p.text||'').join('\n').trim();
    if(!answer)return json({error:'No answer was returned. Please try rephrasing the question.'},502);
    const verified=bookUrl&&candidate?.urlContextMetadata?.urlMetadata?.some(x=>x.urlRetrievalStatus==='URL_RETRIEVAL_STATUS_SUCCESS'&&x.retrievedUrl?.replace(/\/$/,'')===bookUrl.replace(/\/$/,''));
    const sources:Array<{title:string;url:string}>=[];
    if(verified&&bookUrl&&book)sources.push({title:book.title,url:bookUrl});
    const chunks=candidate?.groundingMetadata?.groundingChunks||[],indexes=new Map<number,number>();
    chunks.forEach((c,i)=>{if(safeURL(c.web?.uri)){sources.push({title:c.web?.title||'Verified web source',url:c.web.uri});indexes.set(i,sources.length);}});
    const supports=[...(candidate?.groundingMetadata?.groundingSupports||[])].sort((a,b)=>(b.segment?.endIndex||0)-(a.segment?.endIndex||0));
    for(const support of supports){const index=support.segment?.endIndex;if(typeof index==='number'&&index<=answer.length){const refs=(support.groundingChunkIndices||[]).filter(i=>indexes.has(i)).map(i=>'['+indexes.get(i)+']').join('');answer=answer.slice(0,index)+refs+answer.slice(index);}}
    if(!verified)answer='General learning help — the textbook wording was not verified for this answer.\n\n'+answer;
    return json({answer,sources,searchHtml:candidate?.groundingMetadata?.searchEntryPoint?.renderedContent||null});
  }catch{return json({error:'The AI request timed out or lost its connection. Please try again.'},502);}
}
